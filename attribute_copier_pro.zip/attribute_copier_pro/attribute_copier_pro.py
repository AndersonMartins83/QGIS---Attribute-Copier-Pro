# -*- coding: utf-8 -*-
import os.path
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsProject, QgsVectorLayer, Qgis

from .resources import *
from .attribute_copier_dockwidget import AttributeCopierDockWidget
from .attribute_copier_pro_map_tool import AttributeCopyProMapTool

class AttributeCopierPro:
    """Implementação do Plugin QGIS Genérico."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr(u'&Attribute Copier Pro')
        self.toolbar = self.iface.addToolBar(u'AttributeCopierPro')
        self.toolbar.setObjectName(u'AttributeCopierPro')
        
        self.dockwidget = None
        self.map_tool = None
        self.is_tool_active = False

    def tr(self, message):
        return QCoreApplication.translate('AttributeCopierPro', message)

    def add_action(self, icon_path, text, callback, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        self.iface.addToolBarIcon(action)
        self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)
        return action

    def initGui(self):
        icon_path = ':/plugins/attribute_copier/icon.png'
        self.action = self.add_action(
            icon_path,
            text=self.tr(u'Attribute Copier Pro Tool'),
            callback=self.run,
            parent=self.iface.mainWindow())

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&Attribute Copier Pro'), action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar
        if self.dockwidget:
            self.iface.removeDockWidget(self.dockwidget)

    def run(self):
        if not self.dockwidget:
            self.dockwidget = AttributeCopierDockWidget()
            self.dockwidget.closingPlugin.connect(self.onClosePlugin)
            self.dockwidget.btn_toggle_tool.clicked.connect(self.toggle_tool_state)
            self.dockwidget.combo_layer_source.currentIndexChanged.connect(self.update_source_fields)
            self.dockwidget.combo_layer_target.currentIndexChanged.connect(self.update_target_fields)

        self.populate_layer_combos()
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dockwidget)
        self.dockwidget.show()

    def populate_layer_combos(self):
        self.dockwidget.combo_layer_source.clear()
        self.dockwidget.combo_layer_target.clear()
        
        # MUDANÇA PRINCIPAL: Pega TODAS as camadas vetoriais, sem filtro de geometria
        layers = [layer for layer in QgsProject.instance().mapLayers().values() if isinstance(layer, QgsVectorLayer)]
        
        for layer in layers:
            self.dockwidget.combo_layer_source.addItem(layer.name(), layer)
            self.dockwidget.combo_layer_target.addItem(layer.name(), layer)

    def update_source_fields(self):
        layer = self.dockwidget.combo_layer_source.currentData()
        field_combo = self.dockwidget.combo_field_source
        field_combo.clear()
        if layer:
            for field in layer.fields():
                field_combo.addItem(field.name())

    def update_target_fields(self):
        layer = self.dockwidget.combo_layer_target.currentData()
        field_combo = self.dockwidget.combo_field_target
        field_combo.clear()
        if layer:
            for field in layer.fields():
                field_combo.addItem(field.name())

    def toggle_tool_state(self):
        if self.is_tool_active:
            self.deactivate_tool()
        else:
            self.activate_tool()

    def activate_tool(self):
        source_layer = self.dockwidget.combo_layer_source.currentData()
        source_field = self.dockwidget.combo_field_source.currentText()
        target_layer = self.dockwidget.combo_layer_target.currentData()
        target_field = self.dockwidget.combo_field_target.currentText()
        status_label = self.dockwidget.lbl_status

        if not all([source_layer, source_field, target_layer, target_field]):
            self.iface.messageBar().pushMessage("Erro", "Por favor, selecione todas as camadas e campos.", level=Qgis.Critical, duration=3)
            return
            
        self.map_tool = AttributeCopyProMapTool(self.iface.mapCanvas(), source_layer, source_field, target_layer, target_field, status_label)
        self.iface.mapCanvas().setMapTool(self.map_tool)
        
        self.is_tool_active = True
        self.dockwidget.btn_toggle_tool.setText("Parar Ferramenta")
        status_label.setText("Ferramenta ativa. Clique na feição de ORIGEM.")
        status_label.setStyleSheet("color: blue;")

    def deactivate_tool(self):
        if self.map_tool:
            self.iface.mapCanvas().unsetMapTool(self.map_tool)
            self.map_tool = None
            
        self.is_tool_active = False
        self.dockwidget.btn_toggle_tool.setText("Iniciar Ferramenta")
        self.dockwidget.lbl_status.setText("Ferramenta inativa.")
        self.dockwidget.lbl_status.setStyleSheet("color: black;")

    def onClosePlugin(self):
        self.deactivate_tool()
        self.dockwidget = None
