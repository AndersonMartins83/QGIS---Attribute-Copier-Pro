# -*- coding: utf-8 -*-
# Este script inicializa o plugin, tornando-o conhecido pelo QGIS.

def classFactory(iface):
    """Carrega a classe principal do arquivo do plugin."""
    from .attribute_copier_pro import AttributeCopierPro
    return AttributeCopierPro(iface)
