# Dentro de attribute_copier_pro_map_tool.py

from qgis.core import *
from qgis.gui import *
from qgis.PyQt.QtCore import Qt, QPoint, QRect

class AttributeCopyProMapTool(QgsMapToolEmitPoint):
    def __init__(self, canvas, source_layer, source_field, target_layer, target_field, status_label):
        super().__init__(canvas)
        self.canvas = canvas
        self.source_layer = source_layer
        self.source_field = source_field
        self.target_layer = target_layer
        self.target_field = target_field
        self.status_label = status_label
        self.source_value = None
        self.source_feature_id = None # Nome mais genérico
        self.canvas.setCursor(Qt.CrossCursor)

    def canvasPressEvent(self, event):
        if self.source_value is None:
            self.select_source_feature(event) # Nome do método atualizado
        else:
            self.select_target_feature(event) # Nome do método atualizado
    
    def select_source_feature(self, event):
        pixel_tolerance = 10
        click_pos_pixels = event.pos()
        pixel_rect = QRect(
            click_pos_pixels - QPoint(pixel_tolerance, pixel_tolerance),
            click_pos_pixels + QPoint(pixel_tolerance, pixel_tolerance)
        )
        top_left_map = self.toMapCoordinates(pixel_rect.topLeft())
        bottom_right_map = self.toMapCoordinates(pixel_rect.bottomRight())
        map_rect = QgsRectangle(top_left_map, bottom_right_map)
        
        request = QgsFeatureRequest().setFilterRect(map_rect).setFlags(QgsFeatureRequest.NoGeometry)
        found_features = list(self.source_layer.getFeatures(request))

        if found_features:
            source_feature = found_features[0]
            self.source_value = source_feature[self.source_field]
            self.source_feature_id = source_feature.id()
            
            msg = f"Valor '{self.source_value}' copiado. Clique na feição de DESTINO."
            self.status_label.setText(msg)
            self.status_label.setStyleSheet("color: green;")
        else:
            self.status_label.setText("Nenhuma feição de origem encontrada. Tente novamente.")
            self.status_label.setStyleSheet("color: red;")

    def select_target_feature(self, event):
        pixel_tolerance = 10
        click_pos_pixels = event.pos()
        pixel_rect = QRect(
            click_pos_pixels - QPoint(pixel_tolerance, pixel_tolerance),
            click_pos_pixels + QPoint(pixel_tolerance, pixel_tolerance)
        )
        top_left_map = self.toMapCoordinates(pixel_rect.topLeft())
        bottom_right_map = self.toMapCoordinates(pixel_rect.bottomRight())
        map_rect = QgsRectangle(top_left_map, bottom_right_map)

        request = QgsFeatureRequest().setFilterRect(map_rect)
        found_features = list(self.target_layer.getFeatures(request))

        if found_features:
            target_feature = found_features[0]
            
            if self.source_layer.id() == self.target_layer.id() and self.source_feature_id == target_feature.id():
                self.status_label.setText("Origem e destino são a mesma feição. Escolha outro destino.")
                self.status_label.setStyleSheet("color: orange;")
                return

            try:
                self.target_layer.startEditing()
                target_field_index = self.target_layer.fields().indexOf(self.target_field)
                self.target_layer.changeAttributeValue(target_feature.id(), target_field_index, self.source_value)
                self.target_layer.commitChanges()
                
                msg = f"Valor colado na feição ID {target_feature.id()}. Clique em uma nova feição de ORIGEM."
                self.status_label.setText(msg)
                self.status_label.setStyleSheet("color: blue;")
                
                self.source_value = None
                self.source_feature_id = None
                
            except Exception as e:
                self.target_layer.rollBack()
                self.status_label.setText(f"Erro ao editar feição: {e}")
                self.status_label.setStyleSheet("color: red;")
        else:
            self.status_label.setText(f"Nenhuma feição de destino encontrada. Tente novamente.")
            self.status_label.setStyleSheet("color: red;")

    def deactivate(self):
        self.canvas.setCursor(Qt.ArrowCursor)
        super().deactivate()
